package io.samul.aries;

import java.util.concurrent.BlockingQueue;
import java.net.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DamqRcvProducer implements Runnable {
  private static final Logger logger = LoggerFactory.getLogger(DamqRcvProducer.class);
  private BlockingQueue<DamqMsg> recvQueue;
  DamqSndProducer sndProducer = DamqSndProducer.getInstance();

  public DamqRcvProducer(BlockingQueue<DamqMsg> q) {
    this.recvQueue = q;
  }

  public void run() {
    logger.debug("DamqRcvProducer begins.");

    byte[] rcvBuf = new byte[131072];
    DatagramSocket udpSocket = null;
    boolean socket_is_good = false;

    try {
      udpSocket = new DatagramSocket(DamqRcvConsumer.ModulePort[DamqRcvConsumer.myModuleType]);
      socket_is_good = true;
    } catch (Exception e) {
      logger.error("Error : " + e.getMessage());
    }

    while (socket_is_good) {
      try {
        DatagramPacket packet = new DatagramPacket(rcvBuf, rcvBuf.length);
        udpSocket.setSoTimeout(2000);
        udpSocket.receive(packet);
        udpSocket.setSoTimeout(0);
        String rcvStr = new String(rcvBuf, 0, packet.getLength());
        recvQueue.put(new DamqMsg(rcvStr));
        if (sndProducer.IsTerminateSignal(rcvStr)) {
          logger.debug("rcvProducer: SIG_TERM");
          break;
        }
        Thread.sleep(0);
      } catch (Exception e) {
        if (!(e instanceof SocketTimeoutException)) {
          if (e instanceof SocketException) {
            logger.error("err0r : " + e.getMessage());
          } else {
        	if (!e.getMessage().equals("null")) {
        		logger.error("3rr0r : " + e.getMessage());
        	}
          }
        }
        continue;
      }
    }

    udpSocket.close();
    logger.debug("DamqRcvProducer ends.");
  }
}
