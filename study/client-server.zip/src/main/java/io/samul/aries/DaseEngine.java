package io.samul.aries;

import org.json.JSONObject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DaseEngine extends DamqRcvConsumer {
  private static final Logger logger = LoggerFactory.getLogger(DaseEngine.class);

  public DaseEngine() {
    super();
  }

  public DaseEngine(ModuleType m) {
    super(m);
  }

  protected void MainProc(String org, String dst, String dateTime, String msgId, String msgType, String workCode, String msgBody) {
    logger.debug("i got msg from " + org + " & msgid:" + msgId + " & body:" + msgBody);
  }

  protected void ExceptionProc(Exception e) {
    if (e instanceof InterruptedException) {
      logger.error("error: " + e.getMessage());
    } else {
      logger.error("err0r: " + e.getMessage());
    }
  }
}
