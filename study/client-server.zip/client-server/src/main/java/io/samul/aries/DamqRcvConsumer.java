package io.samul.aries;

import java.util.concurrent.*;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class DamqRcvConsumer implements Runnable {

  /**
   * @name kyl
   * enum 하나로 통합
   */
  public enum ModuleV2 {
    APP("app","10.167.8.113",5001),
    NGIN("ngin","10.167.9.53",5002),
    DEVMGR("devmgr","10.167.9.54",5003),
    COMCLNT("common","10.167.8.11",5004);
    private final String moduleName;
    private final String moduleAddress;
    private final int modulePort;

    ModuleV2(String moduleName, String moduleAddress, int modulePort) {
        this.moduleName = moduleName;
        this.moduleAddress = moduleAddress;
        this.modulePort = modulePort;
    }

    public String getModuleName() { return moduleName; }

    public String getModuleAddress() { return moduleAddress; }

    public int getModulePort() { return modulePort; }
  }

  /**
   * @name kyl
   * enum 하나로 통합
   */
  public enum MessageV2 {
    Request("req"), Response("res");
    private final String msgTypeName;
    MessageV2(String msgTypeName) { this.msgTypeName = msgTypeName; }

    public String getMsgTypeName() { return msgTypeName; }
  }

//  public enum ModuleType {
//    APP(0), NGIN(1), DEVMGR(2), COMCLNT(3);
//    private int _value;
//    ModuleType(int Value) { this._value = Value; }
//    public int getValue() { return _value; }
//  }
//
//  public enum MsgType {
//    Request(0), Response(1);
//    private int _value;
//    MsgType(int Value) { this._value = Value; }
//    public int getValue() { return _value; }
//  }
//  public static String[] ModuleName = { "app", "ngin", "devmgr", "common" };
//  public static String[] ModuleAddress = { "10.167.8.113", "10.167.9.53", "10.167.9.54", "10.167.8.11" };
//  //public static String[] ModuleAddress = { "10.167.106.90", "10.167.9.53", "10.167.9.54", "10.167.8.11" };
//  public static int[] ModulePort = { 5001, 5002, 5003, 5004 };
//  public static String[] MsgTypeName = { "req", "res" };

  private static final Logger logger = LoggerFactory.getLogger(DamqRcvConsumer.class);
  public static ModuleV2 myModuleType;

  // 수신 Producer 핸들
  Runnable rcvProducerRun = null;
  Thread rcvProducer = null;

  // 수신 Consumer
  // 지금 보시는 이 this class 가 수신 consumer 입니다.
  // 추상메소드 abstract void MainProc() 를 구현하세요.

  // 송신 Producer
  // Singleton 이니까 필요한 메소드를 알아서 그냥 땡겨쓰세요.
  protected DamqSndProducer sndProducer = DamqSndProducer.getInstance();

  // 송신 Consumer 핸들
  Runnable sndConsumerRun = null;
  Thread sndConsumer = null;

  // 수신큐
  /**
   * @name : kyl
   * BlockingQueue란?
   * 1. null을 허용하지 않음, null값을 add/put/offer을 하면 NullPointerException 발생
   * 2. capacity bound
   *   - BlockingQueue는 용량,capacity에 제한을 둘 수 있음
   *   - capacity 제약을 두지 않으면 Integer.MAX_VALUE
   * 3. Collection 인터페이스 지원
   *   - BlockingQueue는 Producer-Consumer 패턴의 대기열 목적으로 디자인되었음
   *   - 하지만, 그래도 Collection 인터페이스를 지원해서, remove(x)와 같이 임의의 데이터를 Queue에서 지울 수 있음
   * 4. Thread-safe하게 구현
   *   - 모든 Queue 메소드들은 내부적으로 locks 또는 동시성 제어를 사용하여 원자성을 보장함
   *   - 하지만 Bulk Collection Operations (addAll, containsAll, retainAll, removeAll 등)은 원자성을 보장하지 않음
   *   - 원자성을 보장하려면 따로 구현을 해야함
   *   - addAll(c)로 100개의 데이터를 queue에 넣을 때, 일부는 넣고 실패할 수 있음 (throwing Exception)
   * 5. 더 이상 데이터가 추가되지 않는 것을 나타내기 위한 close,shutdown같은 작업을 지원하지 않음
   */
  protected BlockingQueue<DamqMsg> rcvQueue = new ArrayBlockingQueue<>(16384);
  // 송신큐
  protected BlockingQueue<DamqMsg> sndQueue = new ArrayBlockingQueue<>(16384);

  public DamqRcvConsumer() {
    myModuleType = ModuleV2.NGIN;
  }

  public DamqRcvConsumer(ModuleV2 module) {
    myModuleType = module;
  }

  protected void StartJobs() {
    rcvProducerRun = new DamqRcvProducer(rcvQueue);
    rcvProducer = new Thread(rcvProducerRun);
    rcvProducer.start();

    sndProducer.InitDamqSndProducer(sndQueue);

    sndConsumerRun = new DamqSndConsumer(sndQueue);
    sndConsumer = new Thread(sndConsumerRun);
    sndConsumer.start();
  }

  public void run() {
    logger.debug("DamqRcvConsumer begins.");
    StartJobs();

    while (true) {
      try {
        String rcvBuf = rcvQueue.take().getMsg();
        if (sndProducer.IsTerminateSignal(rcvBuf)) {
          logger.debug("rcvConsumer: SIG_TERM");
          break;
        }
        JSONObject jo = new JSONObject(rcvBuf);
        String org = jo.get("org").toString();
        String dst = jo.get("dst").toString();
        String dateTime = jo.get("date").toString();
        String msgId = jo.get("msgid").toString();
        String msgType = jo.get("msgtype").toString();
        String workCode = jo.get("workcode").toString();
        String msgBody = jo.get("body").toString();
        MainProc(org, dst, dateTime, msgId, msgType, workCode, msgBody);
        Thread.sleep(0);
      } catch (Exception e) {
        ExceptionProc(e);
        continue;
      }
    }

    try {
      rcvProducer.join();
      sndConsumer.join();
    } catch (Exception e) {
      if (e instanceof InterruptedException) {
        logger.error("3rror: " + e.getMessage());
      } else {
        logger.error("3rr0r: " + e.getMessage());
      }
    }
    logger.debug("DamqRcvConsumer ends.");
    logger.debug("All threads joined.");
  }

  protected abstract void MainProc(String org, String dst, String dateTime, String msgId, String msgType, String workCode, String msgBody);
  protected abstract void ExceptionProc(Exception e);
}
