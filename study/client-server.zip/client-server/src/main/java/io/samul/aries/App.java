package io.samul.aries;

import io.samul.aries.DamqRcvConsumer.MessageV2;
import io.samul.aries.DamqRcvConsumer.ModuleV2;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class App
{
  private static final Logger logger = LoggerFactory.getLogger(App.class);

  public static void main(String[] args) {
    logger.debug("Hola");

    try {
      /* 4가지 중 자신의 module type을 파라미터로 넘겨줍니다.
       * ModuleType.COMCLNT | ModuleType.DEVMGR | ModuleType.APP | ModuleType.NGIN
       */
      Runnable damqRun = new DaseEngine(ModuleV2.NGIN);
      Thread damqThread = new Thread(damqRun);
      damqThread.start();

      //test
      DamqSndProducer sndProducer = DamqSndProducer.getInstance();
      for (int i = 0; i < 5; i++) {
        String buf = String.format("{\"index\":\"%d\",\"value\":\"200 OK\"}", i);
        sndProducer.PushToSendQueue(ModuleV2.NGIN, MessageV2.Request, "signin", buf);
      }

      sndProducer.SendExitSignal();

      damqThread.join();
    } catch (Exception e) {
      if (e instanceof InterruptedException) {
        logger.error("main error: " + e.getMessage());
      } else {
        logger.error("ma1n error: " + e.getMessage());
      }
    }

    logger.debug("Adios");

    System.exit(0);
  }
}
